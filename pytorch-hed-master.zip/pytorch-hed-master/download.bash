#!/bin/bash

wget --timestamping http://content.sniklaus.com/github/pytorch-hed/network-bsds500.pytorch